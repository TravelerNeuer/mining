#!/bin/bash

while true
do
./wildrig-multi --algo megabtx --url stratum+tcp://stratum-eu.rplant.xyz:7066 --user sY7v3ieNguMPRd8XkzGdUtASDZFrCvdAmn --pass x
sleep 5
done
