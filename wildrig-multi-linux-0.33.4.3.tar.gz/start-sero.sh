#!/bin/bash

while true
do
./wildrig-multi --algo progpow-sero --url stratum+tcp://pool2.sero.cash:8808 --worker test --user xHFXE293qQuP5qVXKpsrVVRu7HNyC3KNRJQZ4LXKBmcXzusA9hgdWitdwyhuhpSBTpSF3zvUvZLyTFAnwTDpVtWjGzpwzHZriVwE4dHgGsuAGDZ15B6coaUa4mG5EMdr8NY --pass x
sleep 5
done
